package com.example.week10_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
