package com.example.week11_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
